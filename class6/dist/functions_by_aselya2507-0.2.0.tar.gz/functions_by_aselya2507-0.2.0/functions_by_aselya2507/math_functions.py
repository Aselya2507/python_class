def multiplication(NUMBER1, NUMBER2):
    print(NUMBER1 * NUMBER2)

def division(NUMBER1, NUMBER2):
    print(NUMBER1 / NUMBER2)

def addition(NUMBER1, NUMBER2):
    print(NUMBER1 + NUMBER2)

def substraction(NUMBER1, NUMBER2):
    print(NUMBER1 - NUMBER2)